/* Versions of the 'struct stat' data structure used in compatibility xstat
   functions.  */
#define _STAT_VER 0
#define _MKNOD_VER 0
