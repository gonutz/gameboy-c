/* No thread support.  */
