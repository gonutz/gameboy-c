/* __dso_handle is always defined by either crtbegin.o from GCC or our
   dso_handle.c.  */
extern void *__dso_handle __attribute__ ((__visibility__ ("hidden")));
