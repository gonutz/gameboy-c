/* This is a placeholder used only while compiling libc.
   The installed gnu/stubs.h file is created by make install.  */
